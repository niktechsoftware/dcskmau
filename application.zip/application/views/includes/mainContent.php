<?php
	$this->load->view('includes/header');
	$this->load->view('includes/menuAdmin');
	$this->load->view('includes/menuLeft');
	$this->load->view('includes/pageHeader');
	$this->load->view($mainContent);
	$this->load->view('includes/footer');
?>